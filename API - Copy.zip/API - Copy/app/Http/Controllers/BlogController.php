<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class BlogController extends Controller
{
    public function index()
    {
        $blogs = Blog::all();
        return response()->json([
            "status" => "Success",
            "content" => $blogs,
        ], 200);
    }

    public function find($id)
    {
        try {
            $blog = Blog::findOrFail($id);
            return response()->json([
                "status" => "Success",
                "content" => $blog,
            ], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                "status" => "Not Found",
            ], 404);
        }
    }

    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "blog_image" => "required",
            "blog_title" => "required",
            "description" => "required",
            "author" => "required",
            "tags" => "nullable",
        ]);
        $input = [
            "blog_image" => $request->blog_image,
            "blog_title" => $request->blog_title,
            "description" => $request->description,
            "author" => $request-> author,
            "tags" => $request-> tags,
        ];
        if ($validator->fails()) {
            return response()->json([
                "status" => "invalid",
                "content" => $validator->errors(),
            ], 400);
        } else {
            Blog::create($input);
            return response()->json([
                "status" => "success",
            ], 201);
        }
    }

    public function edit(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            "blog_image" => "required",
            "blog_title" => "required",
            "description" => "required",
            "author" => "required",
            "tags" => "nullable",
        ]);
        $input = [
            "blog_image" => $request->blog_image,
            "blog_title" => $request->blog_title,
            "description" => $request->description,
            "author" => $request-> author,
            "tags" => $request-> tags,
        ];

        if ($validator->fails()) {
            return response()->json([
                "status" => "invalid",
                "content" => $validator->errors(),
            ], 400);
        } else {
            try {
                $blog = Blog::findOrFail($id);
                $blog->update($input);
                return response()->json([
                    "status" => "success",
                ], 200);
            } catch (ModelNotFoundException $e) {
                return response()->json([
                    "status" => "Not Found",
                ], 404);
            }
        }
    }

    public function destroy($id)
    {
        try {
            $blog = Blog::findOrFail($id);
            $blog->delete();
            return response()->json([
                "status" => "success",
            ], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                "status" => "Not Found",
            ], 404);
        }
    }
}
