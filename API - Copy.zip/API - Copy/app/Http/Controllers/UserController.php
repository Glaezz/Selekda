<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $user = User::all();
        $resp = [
            "status" => "Success",
            "content" => $user,
        ];
        return response()->json($resp, 200);
    }

    public function find($id){
        try{
            $user = User::findOrFail($id);
            return response()->json([
                "status" => "Success",
                "content" => $user,
            ], 200);
        }catch(ModelNotFoundException $e){
            return response()->json([
                "status" => "Not Found",
            ], 404);
        };
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {
        $validator = Validator::make($request->all(),[
            "name" => "required",
            "username" => "required",
            "email" => "required|email",
            "password" => "required",
            "date_of_birth" => "required|date_format:Y-m-d",
            "phone_number" => "required",

        ]);
        $input = [
            "name" => $request->name,
            "username" => $request->username,
            "email" => $request->email,
            "password" => $request-> password,
            "date_of_birth" => $request-> date_of_birth,
            "phone_number" => $request -> phone_number
        ];

        if($validator->fails()){
            return response()->json([
                "status"=>"invalid",
                "content"=>$validator->errors(),
            ], 400);
        }else{
            User::create($input);
            return response()->json([
                "status" => "success",
            ], 201);
        }
    }

    public function edit(Request $request, $id){
        $validator = Validator::make($request->all(),[
            "name" => "required",
            "username" => "required",
            "email" => "required|email",
            "password" => "required",
            "date_of_birth" => "required|date_format:Y-m-d",
            "phone_number" => "required",
        ]);
        $input = [
            "name" => $request->name,
            "username" => $request->username,
            "email" => $request->email,
            "password" => $request-> password,
            "date_of_birth" => $request-> date_of_birth,
            "phone_number" => $request -> phone_number
        ];
        if($validator->fails()){
            return response()->json([
                "status"=>"invalid",
                "content"=>$validator->errors(),
            ], 400);
        }else{
            try{
                $user = User::findOrFail($id);
                $user->update($input);
                return response()->json([
                    "status" => "success",
                ], 200);
            }catch(ModelNotFoundException $e){
                return response()->json([
                    "status" => "Not Found",
                ], 404);
            };
        }
    }

    public function destroy($id){
        try{
            $user = User::findOrFail($id);
            $user->delete();
            return response()->json([
                "status" => "success",
            ], 200);
        }catch(ModelNotFoundException $e){
            return response()->json([
                "status" => "Not Found",
            ], 404);
        };
    }

}
