<?php

namespace App\Http\Controllers;

use App\Models\Banner;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class BannerController extends Controller
{
    public function index()
    {
        $banners = Banner::all();
        return response()->json([
            "status" => "Success",
            "content" => $banners,
        ], 200);
    }

    public function find($id)
    {
        try {
            $banner = Banner::findOrFail($id);
            return response()->json([
                "status" => "Success",
                "content" => $banner,
            ], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                "status" => "Not Found",
            ], 404);
        }
    }

    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "banner_title" => "required",
            "banner_image" => "required",
            "description" => "nullable",
            "status" => "required|in:active,inactive",
            "date" => "required|date",
        ]);

        if ($validator->fails()) {
            return response()->json([
                "status" => "invalid",
                "content" => $validator->errors(),
            ], 400);
        } else {
            Banner::create($request->all());
            return response()->json([
                "status" => "success",
            ], 201);
        }
    }

    public function edit(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            "banner_title" => "required",
            "banner_image" => "required",
            "description" => "nullable",
            "status" => "required|in:active,inactive",
            "date" => "required|date",
        ]);

        if ($validator->fails()) {
            return response()->json([
                "status" => "invalid",
                "content" => $validator->errors(),
            ], 400);
        } else {
            try {
                $banner = Banner::findOrFail($id);
                $banner->update($request->all());
                return response()->json([
                    "status" => "success",
                ], 200);
            } catch (ModelNotFoundException $e) {
                return response()->json([
                    "status" => "Not Found",
                ], 404);
            }
        }
    }

    public function destroy($id)
    {
        try {
            $banner = Banner::findOrFail($id);
            $banner->delete();
            return response()->json([
                "status" => "success",
            ], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                "status" => "Not Found",
            ], 404);
        }
    }
}
