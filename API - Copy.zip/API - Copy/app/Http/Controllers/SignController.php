<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Symfony\Component\HttpKernel\Event\ResponseEvent;

class SignController extends Controller
{

    /**
     * Store a newly created resource in storage.
     */
    public function signin(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "username" => "required",
            "password" => "required",
        ]);
        $input = [
            "username" => $request->username,
            "password" => $request-> password,
        ];
        if($validator->fails()){
            return response()->json([
                "status" => "invalid",
                "content" => $validator->errors(),
            ], 400);
        } else if(Auth::attempt($input)){
            $token = Auth::user();
            $token = $token->createToken("auth-token")->plainTextToken;
            $content = [
                "token" => $token,
                "username" => $request->username,
            ];
            return response()->json([
                "status" => "Success",
                "content" => $content
            ], 200);
        } else {
            return response()->json([
                "status" => "Failed",
                "content" => "Username or Password not match"
            ], 403);
        };
    }

    /**
     * Display the specified resource.
     */
    public function signout(Request $request){
        auth('sanctum')->user()->tokens()->delete();
        Auth::logout();
        $resp = [
            "status" => "success",
            "message" => "Success Signout"
        ];
        return response()->json($resp, 200);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
