<?php

namespace App\Http\Controllers;

use App\Models\Portfolio;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PortfolioController extends Controller
{
    public function index()
    {
        $portfolios = Portfolio::all();
        return response()->json([
            "status" => "Success",
            "content" => $portfolios,
        ], 200);
    }

    public function find($id)
    {
        try {
            $portfolio = Portfolio::findOrFail($id);
            return response()->json([
                "status" => "Success",
                "content" => $portfolio,
            ], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                "status" => "Not Found",
            ], 404);
        }
    }

    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "portfolio_title" => "required",
            "portfolio_image" => "required",
            "description" => "nullable",
            "author" => "required",
        ]);

        if ($validator->fails()) {
            return response()->json([
                "status" => "invalid",
                "content" => $validator->errors(),
            ], 400);
        } else {
            Portfolio::create($request->all());
            return response()->json([
                "status" => "success",
            ], 201);
        }
    }

    public function edit(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            "portfolio_title" => "required",
            "portfolio_image" => "required",
            "description" => "nullable",
            "author" => "required",
        ]);

        if ($validator->fails()) {
            return response()->json([
                "status" => "invalid",
                "content" => $validator->errors(),
            ], 400);
        } else {
            try {
                $portfolio = Portfolio::findOrFail($id);
                $portfolio->update($request->all());
                return response()->json([
                    "status" => "success",
                ], 200);
            } catch (ModelNotFoundException $e) {
                return response()->json([
                    "status" => "Not Found",
                ], 404);
            }
        }
    }

    public function destroy($id)
    {
        try {
            $portfolio = Portfolio::findOrFail($id);
            $portfolio->delete();
            return response()->json([
                "status" => "success",
            ], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                "status" => "Not Found",
            ], 404);
        }
    }
}
