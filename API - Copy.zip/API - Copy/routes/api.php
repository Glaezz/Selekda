<?php

use App\Http\Controllers\BannerController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\PortfolioController;
use App\Http\Controllers\SignController;
use App\Http\Controllers\UserController;
use GuzzleHttp\Middleware;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

route::get("/", function() {
    return response()->json([
        "status" => 401,
        "message" => "Unathorized"
    ]);
}) ->name("login");

Route::prefix("v1")->group(function() {
    Route::prefix("/blog")->group(function() {
        Route::get("/", [BlogController::class, "index"]);
        Route::get("/{id}", [BlogController::class, "find"]);
    });
    Route::prefix("/portfolio")->group(function() {
        Route::get("/", [PortfolioController::class, "index"]);
        Route::get("/{id}", [PortfolioController::class, "find"]);
    });
    Route::prefix("/banner")->group(function() {
        Route::get("/", [BannerController::class, "index"]);
    });


    Route::prefix("/auth")->group(function() {
        Route::get("/signin", [SignController::class, "signin"]);
        Route::get("/signup", [UserController::class, "create"]);
        Route::get("/signout", [SignController::class, "signout"]);

    });
    Route::prefix("/user")->group(function() {

        Route::get("/{id}", [UserController::class, "find"]);
        Route::put("/{id}", [UserController::class, "edit"]);
    });

    Route::group([
        "middleware" => ["auth:sanctum", "is_admin"]
    ], function() {
        Route::prefix('/admin')->group(function () {
            Route::prefix("/user")->group(function() {
                Route::get("/", [UserController::class, "index"]);
                Route::get("/{id}", [UserController::class, "find"]);
                route::post("/", [UserController::class, "create"]);
                Route::put("/{id}", [UserController::class, "edit"]);
                route::delete("/{id}", [UserController::class, "destroy"]);
            });
            Route::prefix("/banner")->group(function() {
                Route::get("/", [BannerController::class, "index"]);
                Route::get("/{id}", [BannerController::class, "find"]);
                route::post("/", [BannerController::class, "create"]);
                Route::put("/{id}", [BannerController::class, "edit"]);
                route::delete("/{id}", [BannerController::class, "destroy"]);
            });
            Route::prefix("/blog")->group(function() {
                Route::get("/", [BlogController::class, "index"]);
                Route::get("/{id}", [BlogController::class, "find"]);
                route::post("/", [BlogController::class, "create"]);
                Route::put("/{id}", [BlogController::class, "edit"]);
                route::delete("/{id}", [BlogController::class, "destroy"]);
            });
            Route::prefix("/portfolio")->group(function() {
                Route::get("/", [PortfolioController::class, "index"]);
                Route::get("/{id}", [PortfolioController::class, "find"]);
                route::post("/", [PortfolioController::class, "create"]);
                Route::put("/{id}", [PortfolioController::class, "edit"]);
                route::delete("/{id}", [PortfolioController::class, "destroy"]);
            });
        });
    });

});
