<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class AdminController extends Controller
{
    public function blogindex(){
        $url = "https://fiezarausyan-mwjr-selekda.someah.id/api/v1/admin";
        $token = session('token');
        $response = Http::withToken($token)->get($url."/blog");
        if($response->ok()){
            $content = $response->getBody()->getContents();
            $array = json_decode($content, true);
            $type = "blog";
            return view("admin", compact("type"))->with("data", $array["content"]);
        }
    }
    public function blogcreate(Request $request){
        $url = "https://fiezarausyan-mwjr-selekda.someah.id/api/v1/admin";
        $token = session('token');
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
        ])->withToken($token)->post($url."/blog", [
            "blog_image" => $request->blog_image,
            "blog_title" => $request->blog_title,
            "description" => $request->description,
            "author" => $request-> author,
            "tags" => $request-> tags,
        ]);
        if($response->created()){
            return redirect()->route("blogindex");
        }else{
            return redirect()->route("blogindex");
        }
    }
    public function blogedit(Request $request, $id){
        $url = "https://fiezarausyan-mwjr-selekda.someah.id/api/v1/admin";
        $token = session('token');
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
        ])->withToken($token)->put($url."/blog"."/".$id, [
            "blog_image" => $request->blog_image,
            "blog_title" => $request->blog_title,
            "description" => $request->description,
            "author" => $request-> author,
            "tags" => $request-> tags,
        ]);
        if($response->ok()){
            return redirect()->route("blogindex");
        }else{
            return redirect()->route("blogindex");
        }
    }
    public function blogdelete(Request $request, $id){
        $url = "https://fiezarausyan-mwjr-selekda.someah.id/api/v1/admin";
        $token = session('token');
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
        ])->withToken($token)->delete($url."/blog"."/".$id);;
        if($response->ok()){
            return redirect()->route("blogindex");
        }else{
            return redirect()->route("blogindex");
        }
    }


    public function portindex(){
        $url = "https://fiezarausyan-mwjr-selekda.someah.id/api/v1/admin";
        $token = session('token');
        $response = Http::withToken($token)->get($url."/portfolio");
        if($response->ok()){
            $content = $response->getBody()->getContents();
            $array = json_decode($content, true);
            $type = "port";
            return view("admin", compact("type"))->with("data", $array["content"]);
        }
    }
    public function portcreate(Request $request){
        $url = "https://fiezarausyan-mwjr-selekda.someah.id/api/v1/admin";
        $token = session('token');
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
        ])->withToken($token)->post($url."/portfolio", [
            "portfolio_image" => $request->portfolio_image,
            "portfolio_title" => $request->portfolio_title,
            "description" => $request->description,
            "author" => $request-> author,
        ]);
        if($response->created()){
            return redirect()->route("portfolioindex");
        }else{
            return redirect()->route("portfolioindex");
        }
    }
    public function portedit(Request $request, $id){
        $url = "https://fiezarausyan-mwjr-selekda.someah.id/api/v1/admin";
        $token = session('token');
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
        ])->withToken($token)->put($url."/portfolio"."/".$id, [
            "portfolio_image" => $request->portfolio_image,
            "portfolio_title" => $request->portfolio_title,
            "description" => $request->description,
            "author" => $request-> author,
        ]);
        if($response->ok()){
            return redirect()->route("portfolioindex");
        }else{
            return redirect()->route("portfolioindex");
        }
    }

    public function portdelete(Request $request, $id){
        $url = "https://fiezarausyan-mwjr-selekda.someah.id/api/v1/admin";
        $token = session('token');
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
        ])->withToken($token)->delete($url."/portfolio"."/".$id);;
        if($response->ok()){
            return redirect()->route("portfolioindex");
        }else{
            return redirect()->route("portfolioindex");
        }
    }

    public function game(){
        if (session()->has('token')) {
            return view("game");
        } else{
            return redirect()->route("sign");
        }
    }
}
