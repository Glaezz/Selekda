<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class PublicController extends Controller
{

    public function landing(){
        $url = "https://fiezarausyan-mwjr-selekda.someah.id/api/v1";
        $response = Http::get($url."/blog");
        if($response->ok()){
            $content = $response->getBody()->getContents();
            $array = json_decode($content, true);
            return view("landing")->with("data", $array["content"]);
        }
    }

    public function blog(){
        $url = "https://fiezarausyan-mwjr-selekda.someah.id/api/v1";
        $response = Http::get($url."/blog");
        if($response->ok()){
            $content = $response->getBody()->getContents();
            $array = json_decode($content, true);
            return view("blog")->with("data", $array["content"]);
        }
    }
    public function detailBlog($id){
        $url = "https://fiezarausyan-mwjr-selekda.someah.id/api/v1";
        $response = Http::get($url."/blog"."/".$id);
        if($response->ok()){
            $content = $response->getBody()->getContents();
            $array = json_decode($content, true);
            return view("DetailBlog")->with("data", $array["content"]);
        }
    }

    public function portfolio(){
        $url = "https://fiezarausyan-mwjr-selekda.someah.id/api/v1";
        $response = Http::get($url."/portfolio");
        if($response->ok()){
            $content = $response->getBody()->getContents();
            $array = json_decode($content, true);
            return view("Portfolio")->with("data", $array["content"]);
        }
    }

    public function sign(){
        return view("sign");
    }
}
