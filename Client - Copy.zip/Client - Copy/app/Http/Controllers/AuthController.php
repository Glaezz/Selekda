<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class AuthController extends Controller
{
    public function signin(Request $request){
        $url = "https://fiezarausyan-mwjr-selekda.someah.id/api/v1/auth";
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
        ])->get($url."/signin", [
            "username" => $request->username,
            "password" => $request->password,
        ]);
        $data = [

        ];
        if($response->ok()){
            $content = $response->getBody()->getContents();
            $array = json_decode($content, true);
            $token = $array["content"]["token"];
            session(['token' => $token]);
            array_push($data, $array["status"]);
            if($request->username == "admin"){
                return redirect(route("admin"));
            };
            return redirect(route("home"));
        } else{
            $content = $response->getBody()->getContents();
            $array = json_decode($content, true);
            foreach ($array["content"] as $key => $value) {
                array_push($data, $value[0]);
            };
            return view("sign")->with("message", $data);
        }
    }

    public function signup(Request $request){
        $url = "https://fiezarausyan-mwjr-selekda.someah.id/api/v1/auth";
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
        ])->get($url."/signup", [
            "name" => $request->name,
            "username" => $request->username,
            "email" => $request->email,
            "password" => $request->password,
            "date_of_birth" => $request->date_of_birth,
            "phone_number" => $request->phone_number,
        ]);
        $data = [

        ];
        if($response->created()){
            $content = $response->getBody()->getContents();
            $array = json_decode($content, true);
            array_push($data, $array["status"]);
            return view("sign")->with("message", $data);
        } else{
            $content = $response->getBody()->getContents();
            $array = json_decode($content, true);
            foreach ($array["content"] as $key => $value) {
                array_push($data, $value[0]);
            }
            return view("sign")->with("message", $data);
        }
    }
}
