const canvas = document.getElementById("canvas");
const context = canvas.getContext('2d');

const cw = context.canvas.width;
const ch = context.canvas.height;

const bgimg = new Image();
bgimg.src = "background1.jpg";

const playerimg = new Image();
playerimg.src = "Idle_000.png";

const goalImg = new Image();
goalImg.src = "Goal - Side.png"

const ballImg = new Image();
ballImg.src = "Ball 01.png"

const player = {
    x: 150,
    y: 350,
    width: 115,
    height: 115
}

const ball = {
    x: 300,
    y: 460,
    width: 20,
    height: 20,
}

function outline() {
    context.beginPath();

    context.moveTo(0, 0);
    context.lineTo(cw, 0);
    context.lineTo(cw, ch);
    context.lineTo(0, ch);
    context.lineTo(0, 0);
    context.drawImage(bgimg, 0, 0, cw, ch);
    context.drawImage(goalImg, 50, 320, 100, 200);

    context.stroke();
}
outline();

function renderPlayer() {
    context.drawImage(playerimg, player.x, player.y, 200, 200);
}
renderPlayer();

function renderBall() {
    context.drawImage(ballImg, ball.x, ball.y, 50, 50);
}
renderBall();

document.addEventListener("keydown", function (e) {
    let key = e.key;
    console.log(key);
    if (key == "a") {
        player.x -= 5
    }
    if (key == "d") {
        player.x += 5
    }
})

function Collision(player, ball) {
    return (
        player.x < ball.x + ball.width &&
        player.x + player.width > ball.x &&
        player.y < ball.y + ball.height &&
        player.y + player.height > ball.y
    );
}

function triggerCollision() {
    if (Collision(player, ball)) {
        if (player.x > ball.x) {
            ball.x -= 5;
        } else {
            ball.x += 5;
        }
    }
}


function animation() {
    context.save();
    context.clearRect(0, 0, cw, ch);
    outline();
    renderPlayer();
    renderBall();
    triggerCollision();
    context.restore();
}

setInterval(animation, 15);
