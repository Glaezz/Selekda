<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PublicController;
use Illuminate\Support\Facades\Route;

// Route::get('/', function () {
//     return view('landing');
// });

Route::get("/", [PublicController::class, "landing"])->name("home");

Route::prefix("/blog")->group(function() {
    Route::get("/", [PublicController::class, "blog"])->name("blog");
    Route::get("/{id}", [PublicController::class, "detailBlog"])->name("detailBlog");
});

Route::prefix("/portfolio")->group(function() {
    Route::get("/", [PublicController::class, "portfolio"])->name("portfolio");
});

Route::prefix("/game")->group(function() {
    Route::get("/", [PublicController::class, "portfolio"])->name("game");
});


Route::prefix("/auth")->group(function() {
    Route::get('/', function () {
        return view('sign');
    })->name("sign");
    Route::post("/signin", [AuthController::class, "signin"])->name("signin");
    Route::post("/signup", [AuthController::class, "signup"])->name("signup");
    Route::get("/signout", [AuthController::class, "signout"])->name("signout");
});

Route::prefix("/game")->group(function() {
    Route::get("/", [AdminController::class, "game"])->name("game");
});


Route::prefix("/admin")->group(function() {
    Route::get('/', function () {
        return view('admin');
    })->name("admin");
    Route::prefix("/blog")->group(function() {
        Route::get("/", [AdminController::class, "blogindex"])->name("blogindex");
        Route::post("/create", function () {
            return view('addblog');
        })->name("blogcreate1");
        Route::post("/", [AdminController::class, "blogcreate"])->name("blogcreate");
        Route::get("/{id}", function () {
            return view('editblog');
        })->name("blogedit1");
        Route::put("/{id}", [AdminController::class, "blogedit"])->name("blogedit");
        Route::delete("/{id}", [AdminController::class, "blogdelete"])->name("blogdelete");
    });
    Route::prefix("/portfolio")->group(function() {
        Route::get("/", [AdminController::class, "portindex"])->name("portfolioindex");
        Route::post("/create", function () {
            return view('addport');
        })->name("portcreate1");
        Route::post("/", [AdminController::class, "portcreate"])->name("portcreate");
        Route::get("/{id}", function () {
            return view('editport');
        })->name("portedit1");
        Route::put("/{id}", [AdminController::class, "portedit"])->name("portedit");
        Route::delete("/{id}", [AdminController::class, "portdelete"])->name("portdelete");
    });

});
