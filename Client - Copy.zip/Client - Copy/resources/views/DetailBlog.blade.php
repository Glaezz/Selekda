<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Webtech Indonesia</title>
    <base href="{{ url('/') }}/" target="">

    <link rel="stylesheet" href="landing.css">
</head>
<!-- Navbar -->
<nav class="head" style="display: flex; max-width: 100vw; height: 80px; background-color: #021926; border-radius: 8px; position: fixed; top:0%; left: 0%">
    <div style="display: flex; justify-content: space-between;align-items: center; width: 100vw; margin-left: 2vw;  margin-right: 3vw;">
        <h1 style="font-size: 24px; font-weight: bold;">
            <img src="Logo_WebTech-removebg-preview.png" width="100px">
        </h1>
        <div style="display: flex; justify-content: space-between; width: 30vw;">
            <a href="{{ route("home") }}">Home</a>
            <a href="{{ route("blog") }}">Blog</a>
            <a href="{{ route("portfolio") }}">Portfolio</a>
            <a href="{{ route("game") }}">Game</a>
            <a href="{{ route("sign") }}">Sign In</a>
        </div>
    </div>
</nav>
    <div class="news">
            <h1 style="font-weight: bold; font-size: 30px; margin-top: 5vh; margin-left: 5vw; margin-bottom:0;">{{ $data["blog_title"] }}</h1>
            <p style="margin-left: 5vw;">{{ $data["created_at"] }} - {{ $data["author"] }}</p>
            <div style="display: flex;  width: 100%; justify-content: space-evenly; flex-wrap: wrap;">
                <img src="{{ $data["blog_image"] }}" alt="" width="60%">
            </div>
            <p style="margin-left: 5vw;">{{ $data["description"] }}</p>

            <h2 style="margin-left: 5vw;">Comment (0)</h2>
    </div>
    <footer style="width: 100wh; height:35vh; background-color: #021926;">
        <div style="display: flex; align-items: center">
            <div style="display: flex; flex-direction: column; margin-left:3vw; justify-content:center">
                <h1 style="font-size: 24px; font-weight: bold;">
                <img src="Logo_WebTech-removebg-preview.png" width="200">
                </h1>
                <p style="max-width: 30vw;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit possimus asperiores vitae a quaerat illum quae fugiat eos ipsum nobis!</p>
                <p>Copyright by Fieza</p>
            </div>

        </div>
    </footer>
</body>
</html>
