<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Webtech Indonesia</title>
    <base href="{{ url('/') }}/" target="">
    <link rel="stylesheet" href="landing.css">
    <link rel="stylesheet" href="sign.css">
</head>
<!-- Navbar -->
<nav class="head" style="display: flex; max-width: 100vw; height: 80px; background-color: #021926; border-radius: 8px; position: fixed; top:0%; left: 0%">
    <div style="display: flex; justify-content: space-between;align-items: center; width: 100vw; margin-left: 2vw;  margin-right: 3vw;">
        <h1 style="font-size: 24px; font-weight: bold;">
            <img src="Logo_WebTech-removebg-preview.png" width="100px">
        </h1>
        <div style="display: flex; justify-content: space-between; width: 30vw;">
            <a href="{{ route("admin") }}">Home</a>
            <a href="{{ route("blogindex") }}">Blog</a>
            <a href="{{ route("portfolioindex") }}">Portfolio</a>
            <a href="{{ route("game") }}">Game</a>
            <a href="{{ route("sign") }}">Sign In</a>
        </div>
    </div>
</nav>
<body>
    <div class="news">
        <h1 style="font-weight: bold; font-size: 50px; margin-bottom: 10vh; align-self: center;">Portfolio</h1>
        <div style="display: flex;  width: 100%; align-items: center; justify-content: space-evenly; flex-wrap: wrap;">
            <div class="container">
                <div class="form-container">
                    <form action="{{ route("portcreate") }}" class="form" method="POST">
                        @csrf
                        <h2>add Portfolio</h2>
                        <input type="text" name="portfolio_image" placeholder="Portfolio Image">
                        <input type="text" name="portfolio_title" placeholder="Portfolio Title">
                        <input type="text" name="description" placeholder="Description">
                        <input type="text" name="author" placeholder="Author">
                        <button type="submit">Submit Portfolio</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
</body>
<footer style="width: 100wh; height:35vh; background-color: #021926;">
    <div style="display: flex; align-items: center">
        <div style="display: flex; flex-direction: column; margin-left:3vw; justify-content:center">
            <h1 style="font-size: 24px; font-weight: bold;">
            <img src="Logo_WebTech-removebg-preview.png" width="200">
            </h1>
            <p style="max-width: 30vw;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit possimus asperiores vitae a quaerat illum quae fugiat eos ipsum nobis!</p>
            <p>Copyright by Fieza</p>
        </div>

    </div>
</footer>
</html>
