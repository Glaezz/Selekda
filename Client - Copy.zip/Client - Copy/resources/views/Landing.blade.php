<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Webtech Indonesia</title>
    <base href="{{ url('/') }}/" target="">
    <link rel="stylesheet" href="landing.css">
</head>
<!-- Navbar -->
<nav class="head"
    style="display: flex; max-width: 100vw; height: 80px; background-color: #021926; border-radius: 8px; position: fixed; top:0%; left: 0%">
    <div
        style="display: flex; justify-content: space-between;align-items: center; width: 100vw; margin-left: 2vw;  margin-right: 3vw;">
        <h1 style="font-size: 24px; font-weight: bold;">
            <img src="Logo_WebTech-removebg-preview.png" width="100px">
        </h1>
        <div style="display: flex; justify-content: space-between; width: 30vw;">
            <a href="{{ route("home") }}">Home</a>
            <a href="{{ route("blog") }}">Blog</a>
            <a href="{{ route("portfolio") }}">Portfolio</a>
            <a href="{{ route("game") }}">Game</a>
            <a href="{{ route("sign") }}">Sign In</a>
        </div>
    </div>
</nav>
<!-- Hero Section -->

<body>
    <div class="hero">
        <div class="hero-content">
            <h1 style="font-weight: bold; font-size: 45px; margin-bottom: 0;">Webtech Indonesia</h1>
            <h4 style="max-width: 50vw; font-weight:100;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Saepe
                veniam debitis voluptatem laborum? Id dicta qui ipsum quo quod possimus.</h4>
            <div
                style="background-color: #284163; width: 140px; height: 40px; display:flex; justify-content: center; align-items:center; border-radius: 8px;">
                <a href="">More</a>
            </div>
        </div>
    </div>
    <div class="service">
        <hr style="color:aliceblue; width: 100%;">
        <h1 style="font-weight: bold; font-size: 30px; margin-bottom: 10vh;">Our Services</h1>
        <div style="display: flex; justify-content: space-evenly;  width: 100%; flex-wrap: wrap;">
            <a href="" style="display: flex; align-items:center; flex-direction: column;">
                <img src="logo.svg" width="60px">
                <p style="font-size: 20px;">Software Development</p>
            </a>
            <a href="" style="display: flex; align-items:center; flex-direction: column;">
                <img src="logo.svg" width="60px">
                <p style="font-size: 20px;">Software Development</p>
            </a>
            <a href="" style="display: flex; align-items:center; flex-direction: column;">
                <img src="logo.svg" width="60px">
                <p style="font-size: 20px;">Software Development</p>
            </a>
        </div>
        <hr style="color:aliceblue; width: 100%;">
    </div>
    <div class="about">
        <h1 style="font-weight: bold; font-size: 30px; margin-bottom: 10vh;">About Us</h1>
        <div style="display: flex;  width: 100%; align-items: center; justify-content: center; flex-wrap: wrap;">
            <img src="images (9).jpg" width="350px">
            <p style="max-width: 50vh; margin-left: 3vw;">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Unde
                neque pariatur alias commodi numquam quia ex, dolorem ad sequi laudantium quas molestias ut corporis
                voluptates, expedita maiores minus dolore rerum sunt tempora at quos quo dignissimos aperiam?
                Distinctio, dolore a? Molestiae nihil officia nesciunt distinctio tempora nobis recusandae, quae sequi.
            </p>
        </div>
    </div>
    <div class="news">
        <h1 style="font-weight: bold; font-size: 30px; margin-bottom: 10vh; align-self: center;">News</h1>
        <div style="display: flex;  width: 100%; align-items: center; justify-content: space-evenly; flex-wrap: wrap;">
            @foreach ($data as $index=>$data)
            <a href="{{ route("detailBlog", $data["id"]) }}" class="card">
                <img src="{{ $data["blog_image"] }}" alt="" width="250px" style="border-radius: 8px;">
                <div style="margin-left: 10px;">
                    <p style="font-size: 18px; font: weight 600px;">{{ $data["blog_title"] }}</p>
                    <p>{{ $data["description"] }}</p>
                </div>
            </a>
            @endforeach
        </div>
    </div>
</body>
<footer style="width: 100wh; height:35vh; background-color: #021926;">
    <div style="display: flex; align-items: center">
        <div style="display: flex; flex-direction: column; margin-left:3vw; justify-content:center">
            <h1 style="font-size: 24px; font-weight: bold;">
                <img src="Logo_WebTech-removebg-preview.png" width="200">
            </h1>
            <p style="max-width: 30vw;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit possimus asperiores
                vitae a quaerat illum quae fugiat eos ipsum nobis!</p>
            <p>Copyright by Fieza</p>
        </div>

    </div>
</footer>

</html>
