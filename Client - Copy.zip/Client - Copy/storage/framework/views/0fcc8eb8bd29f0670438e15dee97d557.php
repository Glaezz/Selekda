<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base href="<?php echo e(url('/')); ?>/" target="">
    <title>World Head Football</title>
</head>
<body style="display: flex; align-items: center; justify-content: center;">
    <canvas id="canvas" width="1000px" height="600px"></canvas>
</body>
<script src="script.js"></script>
</html>
<?php /**PATH D:\Latihan WorldSkill\2024\SELEKDA GASSS\Garap\Front_End\Client\resources\views/game.blade.php ENDPATH**/ ?>