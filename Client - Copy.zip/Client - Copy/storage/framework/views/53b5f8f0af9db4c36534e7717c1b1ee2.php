<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Webtech Indonesia</title>
    <base href="<?php echo e(url('/')); ?>/" target="">
    <link rel="stylesheet" href="landing.css">
    <link rel="stylesheet" href="sign.css">
</head>
<!-- Navbar -->
<nav class="head" style="display: flex; max-width: 100vw; height: 80px; background-color: #021926; border-radius: 8px; position: fixed; top:0%; left: 0%">
    <div style="display: flex; justify-content: space-between;align-items: center; width: 100vw; margin-left: 2vw;  margin-right: 3vw;">
        <h1 style="font-size: 24px; font-weight: bold;">
            <img src="Logo_WebTech-removebg-preview.png" width="100px">
        </h1>
        <div style="display: flex; justify-content: space-between; width: 30vw;">
            <a href="<?php echo e(route("home")); ?>">Home</a>
            <a href="<?php echo e(route("blog")); ?>">Blog</a>
            <a href="<?php echo e(route("portfolio")); ?>">Portfolio</a>
            <a href="<?php echo e(route("game")); ?>">Game</a>
            <a href="<?php echo e(route("sign")); ?>">Sign In</a>
        </div>
    </div>
</nav>
<body>
    <div class="news">
        <h1 style="font-weight: bold; font-size: 50px; margin-bottom: 5vh; align-self: center;">Sign Up</h1>
        <?php if(isset($message)): ?>

        <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p style="font-weight: bold; font-size: 18px; align-self: center; color:red;"><?php echo e($message); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>
        <div style="display: flex;  width: 100%; align-items: center; justify-content: space-evenly; flex-wrap: wrap;">
            <div class="container">
                <div class="form-container">
                    <form class="form" action="<?php echo e(route('signup')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <h2>Register</h2>
                        <input type="text" id="name" placeholder="Name" name="name">
                        <input type="text" id="username" placeholder="Username" name="username">
                        <input type="email" id="email" placeholder="Email" name="email" >
                        <input type="password" id="password" placeholder="Password" name="password">
                        <input type="date" id="birth_of_date" placeholder="Birth Date" name="date_of_birth">
                        <input type="tel" id="phone_number" placeholder="Phone Number" name="phone_number">
                        <button type="submit">Register</button>
                    </form>

                </div>
            </div>
            <div class="container">
                <div class="form-container">
                    <form action="<?php echo e(route('signin')); ?>" class="form" method="POST">
                        <?php echo csrf_field(); ?>
                        <h2>Login</h2>
                        <input type="text" placeholder="Username" name="username">
                        <input type="password" placeholder="Password" name="password">
                        <button type="submit">Login</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
<footer style="width: 100wh; height:35vh; background-color: #021926;">
    <div style="display: flex; align-items: center">
        <div style="display: flex; flex-direction: column; margin-left:3vw; justify-content:center">
            <h1 style="font-size: 24px; font-weight: bold;">
            <img src="Logo_WebTech-removebg-preview.png" width="200">
            </h1>
            <p style="max-width: 30vw;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit possimus asperiores vitae a quaerat illum quae fugiat eos ipsum nobis!</p>
            <p>Copyright by Fieza</p>
        </div>

    </div>
</footer>
</html>
<?php /**PATH D:\Latihan WorldSkill\2024\SELEKDA GASSS\Garap\Front_End\Client\resources\views/sign.blade.php ENDPATH**/ ?>